from torch import nn
import torch


class KronLinear(nn.Module):
    def __init__(self, 
                in_dim,
                out_dim,
                a1,
                a2,
                factors):
        super(KronLinear, self).__init__()
        self.in_dim = in_dim
        self.out_dim = out_dim
        self.a1 = a1
        self.a2 = a2
        self.factors = factors
        self.num_quantums = len(self.a1)
        self.kron_matrix = []
        self.bias = []
        for i in range(self.num_quantums):
            self.kron_matrix.append(nn.Parameter(torch.normal(0, 0.02, size=[self.factors, self.a1[i], self.a2[i]])))
            # self.bias.append(nn.Parameter(torch.zeros(1, a2[i])))
        self.kron_matrix = nn.ParameterList(self.kron_matrix)
        # self.bias_list = nn.ParameterList(self.bias)
        self.bias = nn.Parameter(torch.zeros(out_dim))

    def get_weight(self):
        weight = 0
        for i in range(0, self.factors):
            t_weight = self.kron_matrix[0][i]
            for j in range(1, self.num_quantums):
                t_weight = torch.kron(t_weight, self.kron_matrix[j][i])
            weight += t_weight
        # bias = self.bias_list[0]
        # for i in range(1, self.num_quantums):
        #     bias = torch.kron(bias, self.bias_list[i])
        bias = self.bias
        return weight, bias

    def forward(self, x):
        weight, bias = self.get_weight()
        # print(x.shape)
        out = x @ weight + bias
        # print(x.shape)
        return out


class KronMLP(nn.Module):
    def __init__(self,
                input_dim, 
                hidden_dim, 
                output_dim,
                pair_list:list,
                num_layers,
                factors, 
                dropout_rate) -> None:
        """
        params:
        * input_dim: the input dimension of x
        * hidden_dim: the hidden dimension of the network
        * output_dim: the output dimension of the network
        * pair_list: use list of list to represent the dimension of the kronecker matrix
            * example: use 3 kronecker matrix to replace the original linear network
            * pair_list = [
                [7, 7, 32],
                [7, 7, 16],
                [1, 2, 5]
            ]
            * TODO: Actually, the product of content of pair_list is the corresponding dim such that:
                * input_dim = 1568
                * pair_list[0]'s product = 7*7*32 = 1568
                * So we NEED to find a way to auto generate pair_list
        """
        super(KronMLP, self).__init__()

        self.input_dim = input_dim
        self.hidden_dim = hidden_dim
        self.output_dim = output_dim
        self.factors = factors
        self.pair_list = pair_list
        self.input_layer = KronLinear(input_dim, hidden_dim, self.pair_list[0], self.pair_list[1], factors)
        self.hidden_layers = []
        for _ in range(0, num_layers-2):
            self.hidden_layers.append(KronLinear(hidden_dim, hidden_dim, self.pair_list[1], self.pair_list[1], factors))
        self.hidden_layers = nn.ModuleList(self.hidden_layers)
        self.output_layer = KronLinear(hidden_dim, output_dim, self.pair_list[1], self.pair_list[2], factors)
        self.norm = nn.BatchNorm1d(num_features=hidden_dim, affine=False)
        self.gelu = nn.GELU()
        # self.dropout = nn.Dropout(dropout_rate)

    def forward(self, x):
        out = self.gelu(self.input_layer(x))
        for layer in self.hidden_layers:
            out = self.gelu(layer(out))
        out = self.output_layer(out)
        return out