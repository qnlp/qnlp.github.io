import os
import time
import warnings
warnings.filterwarnings("ignore")
import wandb
wandb.init(project="KronMLP")

import torch
import torch.nn as nn
import torch.utils.data as Data
import torchvision
import matplotlib.pyplot as plt
from torchstat import stat

# Hyper Parameters
config = wandb.config
config.EPOCH = 20               # train the training data n times, to save time, we just train 1 epoch
config.BATCH_SIZE = 50
config.learning_rate = 0.001              # learning rate
DOWNLOAD_MNIST = False
DEVICE = torch.device("cuda:3" if torch.cuda.is_available() else "cpu")

# Mnist digits dataset
if not(os.path.exists('./mnist/')) or not os.listdir('./mnist/'):
    # not mnist dir or mnist is empyt dir
    DOWNLOAD_MNIST = True

train_data = torchvision.datasets.MNIST(
    root='./mnist/',
    train=True,                                     # this is training data
    transform=torchvision.transforms.ToTensor(),    # Converts a PIL.Image or numpy.ndarray to
                                                    # torch.FloatTensor of shape (C x H x W) and normalize in the range [0.0, 1.0]
    download=DOWNLOAD_MNIST,
)

# plot one example
# print(train_data.train_data.size())                 # (60000, 28, 28)
# print(train_data.train_labels.size())               # (60000)
# plt.imshow(train_data.train_data[0].numpy(), cmap='gray')
# plt.title('%i' % train_data.train_labels[0])
# plt.show()

# Data Loader for easy mini-batch return in training, the image batch shape will be (50, 1, 28, 28)
train_loader = Data.DataLoader(dataset=train_data, batch_size=config.BATCH_SIZE, shuffle=True)

# pick 2000 samples to speed up testing
test_data = torchvision.datasets.MNIST(root='./mnist/', train=False)
test_x = torch.unsqueeze(test_data.test_data, dim=1).type(torch.FloatTensor)/255.   # shape from (2000, 28, 28) to (2000, 1, 28, 28), value in range(0,1)
test_y = test_data.test_labels

class MLP(nn.Module):
    def __init__(self):
        super(MLP, self).__init__()
        self.mlp = nn.Sequential(
            nn.Linear(28*28, 28*28),
            nn.GELU(),
            nn.Linear(28*28, 28*28),
            nn.GELU(),
            nn.Linear(28*28, 10),
            nn.Dropout(0.1)
        )

    def forward(self, x):
        output = self.mlp(x)
        return output, x    # return x for visualization
    
mlp = MLP().to(DEVICE)
wandb.watch(mlp)

def get_parameter_number(model):
    total_num = sum(p.numel() for p in model.parameters())
    trainable_num = sum(p.numel() for p in model.parameters() if p.requires_grad)
    return {'Total': total_num, 'Trainable': trainable_num}

param = get_parameter_number(mlp)
print(param)

best_acc = 0
start_time = time.time()
optimizer = torch.optim.Adam(mlp.parameters(), lr=config.learning_rate)   # optimize all logistic parameters
loss_func = nn.CrossEntropyLoss()                       # the target label is not one-hotted

# training and testing
for epoch in range(config.EPOCH):
    for step, (b_x, b_y) in enumerate(train_loader):   # gives batch data, normalize x when iterate train_loader
        # print(b_x.size())
        b_x = b_x.to(DEVICE).view(-1, 28*28)
        # print(b_x.size())

        output = mlp(b_x)[0]               # logistic output
        loss = loss_func(output, b_y.to(DEVICE))   # cross entropy loss
        wandb.log(
            {"mlp mnist training loss": loss}
        )
        optimizer.zero_grad()           # clear gradients for this training step
        loss.backward()                 # backpropagation, compute gradients
        optimizer.step()                # apply gradients

        if step % 50 == 0:

            test_output, last_layer = mlp(test_x.to(DEVICE).view(-1,28*28))
            pred_y = torch.max(test_output.cpu(), 1)[1].data.numpy()
            accuracy = float((pred_y == test_y.data.numpy()).astype(int).sum()) / float(test_y.size(0))
            wandb.log(
                {"mlp mnist test accuracy": accuracy}
            )
            if accuracy > best_acc: best_acc = accuracy
            print('Epoch: ', epoch, '| train loss: %.4f' % loss.item(), '| test accuracy: %.6f' % accuracy)
            

end_time = time.time()
print("Used time is ", str(end_time - start_time))
print("best_acc", best_acc)

# print 10 predictions from test data
test_output, _ = mlp(test_x[:10].to(DEVICE).view(-1,28*28))
pred_y = torch.max(test_output, 1)[1].data.numpy()
print(pred_y, 'prediction number')
print(test_y[:10].numpy(), 'real number')