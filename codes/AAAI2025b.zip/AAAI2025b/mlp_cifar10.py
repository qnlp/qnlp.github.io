import os
import math
import time
import warnings
warnings.filterwarnings("ignore")

import torch
import torch.nn as nn
import torch.utils.data as Data
import torchvision
import matplotlib.pyplot as plt
import torchvision.transforms as transforms
from kron_mlp import KronMLP
import wandb
from utils import get_parameter_number

# os.environ['WANDB_MODE'] = 'offline'
wandb.init(project="KronMLP")

# Hyper Parameters
EPOCH = 20               # train the training data n times, to save time, we just train 1 epoch
BATCH_SIZE = 50
LR = 0.0005              # learning rate
DOWNLOAD_CIFAR = False
DEVICE = torch.device("cuda:7" if torch.cuda.is_available() else "cpu")
factors = 1
dropout_rate = 0.1
# pair_list = [[48, 64],
#             [64, 48],
#             [2, 5]]
pair_list = [[12, 16, 16],
            [16, 16, 12],
            [1, 2, 5]]
# pair_list = [[12, 4, 4, 16],
#             [12, 4, 4, 16],
#             [1, 2, 1, 5]]

# Mnist digits dataset
if not(os.path.exists('./cifar10/')) or not os.listdir('./cifar10/'):
    # not mnist dir or mnist is empyt dir
    DOWNLOAD_CIFAR = True

transform = transforms.Compose(
    [transforms.ToTensor(),
    transforms.Normalize((0.5, 0.5, 0.5), (0.5, 0.5, 0.5))])

trainset = torchvision.datasets.CIFAR10(root='./data', train=True,
                                        download=True, transform=transform)
train_loader = torch.utils.data.DataLoader(trainset, batch_size=128,
                                        shuffle=True, num_workers=2)

testset = torchvision.datasets.CIFAR10(root='./data', train=False,
                                    download=True, transform=transform)
test_loader = torch.utils.data.DataLoader(testset, batch_size=128,
                                        shuffle=False, num_workers=2)

class MLP(nn.Module):
    def __init__(self):
        super(MLP, self).__init__()
        self.mlp = nn.Sequential(
            nn.Linear(3072, 3072),
            nn.GELU(),
            nn.Linear(3072, 3072),
            nn.GELU(),
            nn.Linear(3072, 3072),
            nn.GELU(),
            nn.Linear(3072, 3072),
            nn.GELU(),
            nn.Linear(3072, 3072),
            nn.GELU(),
            nn.Linear(3072, 3072),
            nn.GELU(),
            nn.Linear(3072, 3072),
            nn.GELU(),
            nn.Linear(3072, 3072),
            nn.GELU(),
            nn.Linear(3072, 3072),
            nn.GELU(),
            nn.Linear(3072, 10),
            nn.Dropout(0.1)
        )

    def forward(self, x):
        output = self.mlp(x)
        return output    # return x for visualization
    
mlp = MLP().to(DEVICE)
print(type(mlp))
print(mlp)

wandb.config = {
    "learning_rate": LR,
    "epoch": EPOCH,
    "batch size": BATCH_SIZE,
    "factors": factors,
    "pair_list": pair_list
}

param = get_parameter_number(mlp)

wandb.config.update(param)
print(param)

def train():
    optimizer = torch.optim.Adam(mlp.parameters(), lr=LR)   # optimize all logistic parameters
    loss_func = nn.CrossEntropyLoss()                       # the target label is not one-hotted
    best_acc = 0
    start_time = time.time()
    global_step = 0
    for epoch in range(EPOCH):
        for step, (b_x, b_y) in enumerate(train_loader):   # gives batch data, normalize x when iterate train_loader
            # print(b_x.size())
            b_x, b_y = b_x.to(DEVICE), b_y.to(DEVICE)
            b_x = torch.reshape(b_x, (b_x.size(0), -1))
            output = mlp(b_x)
            loss = loss_func(output, b_y.to(DEVICE))   # cross entropy loss
            optimizer.zero_grad()           # clear gradients for this training step
            loss.backward()                 # backpropagation, compute gradients
            optimizer.step()                # apply gradients

            if step % 50 == 0:
                global_step += step
                # test_x = test_x.to(DEVICE)
                accuracy = test(mlp, test_loader)
                if accuracy > best_acc:
                    best_acc = accuracy
                wandb.log({
                        "loss":loss.item(),
                        "accuracy": accuracy
                }, step = global_step)
                print('Epoch: ', epoch, '| train loss: %.4f' % loss.item(), '| test accuracy: %.6f' % accuracy)
    end_time = time.time()
    print(best_acc)
    wandb.log({'best_acc':best_acc})
    print("Used time is ", str(end_time - start_time))

def test(net, testloader):
    correct = 0
    total = 0
    with torch.no_grad():
        for inputs, labels in testloader:
            inputs = inputs.to(DEVICE).view(inputs.size(0), -1)
            labels = labels.to(DEVICE)
            outputs = net(inputs)
            _, predicted = torch.max(outputs, 1)
            total += labels.size(0)
            correct += (predicted == labels).sum().item()
    # print('Accuracy of the network on the test images: %d %%' % (100 * correct / total))
    return (100 * correct / total)

# # print 10 predictions from test data
# test_output = mlp(test_x[:10].to(DEVICE).view(-1,28*28))
# pred_y = torch.max(test_output.cpu(), 1)[1].data.numpy()
# print(pred_y, 'prediction number')
# print(test_y[:10].numpy(), 'real number')

if __name__ == '__main__':
    columns = ['name', 'data']
    # description = """3 layers(784->784->10), both linear and bias are implement by kron product"""
    data = [["learning_rate", LR],
            ['epoch', EPOCH],
            ['batch size', BATCH_SIZE],
            ['factors', factors],
            ['num_quantums', 2],
            # ['pair list', pair_list[0]],
            ['all params', param['Total']],
            ['trainale params', param['Trainable']]]
            # ['description', description]]
    table = wandb.Table(data=data, columns=columns)
    wandb.log({'hyper params table': table})
    train()