import os
import math
import time
import warnings
warnings.filterwarnings("ignore")

import torch
import torch.nn as nn
import torch.utils.data as Data
import torchvision
import matplotlib.pyplot as plt
from kron_mlp import KronMLP
import wandb
os.environ['WANDB_MODE'] = 'offline'
wandb.init(project="KronMLP")
from utils import get_parameter_number

# Hyper Parameters
config = wandb.config
config.EPOCH = 20               # train the training data n times, to save time, we just train 1 epoch
config.BATCH_SIZE = 50
config.learning_rate = 0.05             # learning rate
DOWNLOAD_MNIST = False
DEVICE = torch.device("cuda:6" if torch.cuda.is_available() else "cpu")

dim_1 = 28
dim_2 = 28
dim_3 = 28
factors = 4
dropout_rate = 0.1

# Mnist digits dataset
if not(os.path.exists('./mnist/')) or not os.listdir('./mnist/'):
    # not mnist dir or mnist is empyt dir
    DOWNLOAD_MNIST = True

train_data = torchvision.datasets.MNIST(
    root='./mnist/',
    train=True,                                     # this is training data
    transform=torchvision.transforms.ToTensor(),    # Converts a PIL.Image or numpy.ndarray to
                                                    # torch.FloatTensor of shape (C x H x W) and normalize in the range [0.0, 1.0]
    download=DOWNLOAD_MNIST,
)

# plot one example
# print(train_data.train_data.size())                 # (60000, 28, 28)
# print(train_data.train_labels.size())               # (60000)
# plt.imshow(train_data.train_data[0].numpy(), cmap='gray')
# plt.title('%i' % train_data.train_labels[0])
# plt.show()

# Data Loader for easy mini-batch return in training, the image batch shape will be (50, 1, 28, 28)
train_loader = Data.DataLoader(dataset=train_data, batch_size=config.BATCH_SIZE, shuffle=True)

# pick 2000 samples to speed up testing
test_data = torchvision.datasets.MNIST(root='./mnist/', train=False)
test_x = torch.unsqueeze(test_data.test_data, dim=1).type(torch.FloatTensor)/255.   # shape from (2000, 28, 28) to (2000, 1, 28, 28), value in range(0,1)
test_y = test_data.test_labels
    
# pair_list = [[28, 28],
#             [28, 28],
#             [2, 5]]

# pair_list = [[7, 7, 16],
#             [16, 7, 7],
#             [2, 5, 1]]

pair_list = [[4, 7, 4, 7],
            [7, 4, 7, 4],
            [1, 2, 5, 1]]

# mlp = KronMLP(input_dim=784,
#               hidden_dim=784,
#               output_dim=10,
#               pair_list=pair_list,
#               num_layers=3,
#               factors=factors,
#               dropout_rate=dropout_rate).to(DEVICE)
class MLP(nn.Module):
    def __init__(self):
        super(MLP, self).__init__()
        self.mlp = nn.Sequential(
            nn.Linear(28*28, 28*28),
            nn.GELU(),
            nn.Linear(28*28, 28*28),
            nn.GELU(),
            nn.Linear(28*28, 10),
            nn.Dropout(0.1)
        )

    def forward(self, x):
        output = self.mlp(x)
        return output   # return x for visualization
    
mlp = KronMLP(
    input_dim=784,
    hidden_dim=784,
    output_dim=10,
    pair_list=pair_list,
    num_layers=3,
    factors=factors, 
    dropout_rate=dropout_rate
).to(DEVICE)
print(type(mlp))
print(mlp)

wandb.config = {
    "learning_rate": config.learning_rate,
    "epoch": config.EPOCH,
    "batch size": config.BATCH_SIZE,
    "factors": factors,
    "pair_list": pair_list
}

param = get_parameter_number(mlp)

wandb.config.update(param)
print(param)

def train():
    optimizer = torch.optim.Adam(mlp.parameters(), lr=config.learning_rate)   # optimize all logistic parameters
    loss_func = nn.CrossEntropyLoss()                       # the target label is not one-hotted
    best_acc = 0
    start_time = time.time()
    global_step = 0
    for epoch in range(config.EPOCH):
        for step, (b_x, b_y) in enumerate(train_loader):   # gives batch data, normalize x when iterate train_loader
            # print(b_x.size())
            b_x = b_x.to(DEVICE).view(-1, 28*28)
            # print(b_x.size())

            output = mlp(b_x)
            loss = loss_func(output, b_y.to(DEVICE))   # cross entropy loss
            wandb.log(
                {"Kronmlp mnist training loss": loss}
            )
            optimizer.zero_grad()           # clear gradients for this training step
            loss.backward()                 # backpropagation, compute gradients
            optimizer.step()                # apply gradients

            if step % 50 == 0:
                global_step += step
                # test_x = test_x.to(DEVICE)
                test_output = mlp(test_x.to(DEVICE).view(-1,28*28))
                pred_y = torch.max(test_output.cpu(), 1)[1].data.numpy()
                accuracy = float((pred_y == test_y.data.numpy()).astype(int).sum()) / float(test_y.size(0))
                wandb.log(
                    {"Kronmlp mnist test accuracy": accuracy}
                )
                if accuracy > best_acc:
                    best_acc = accuracy
                # wandb.log({
                #         "loss":loss.item(),
                #         "accuracy": accuracy
                # }, step = global_step)
                print('Epoch: ', epoch, '| train loss: %.4f' % loss.item(), '| test accuracy: %.6f' % accuracy)
                

    end_time = time.time()
    print(best_acc)
    wandb.log({'best_acc':best_acc})
    print("Used time is ", str(end_time - start_time))

# # print 10 predictions from test data
# test_output = mlp(test_x[:10].to(DEVICE).view(-1,28*28))
# pred_y = torch.max(test_output.cpu(), 1)[1].data.numpy()
# print(pred_y, 'prediction number')
# print(test_y[:10].numpy(), 'real number')

if __name__ == '__main__':
    wandb.init(project="KronMLP",
                entity="kronmlp",
                name="minst-kronmlp-baseline")
    columns = ['name', 'data']
    # description = """3 layers(784->784->10), both linear and bias are implement by kron product"""
    data = [["learning_rate", config.learning_rate],
            ['epoch', config.EPOCH],
            ['batch size', config.BATCH_SIZE],
            ['factors', factors],
            ['num_quantums', 0],
            # ['pair list', pair_list[0]],
            ['all params', param['Total']],
            ['trainale params', param['Trainable']]]
            # ['description', description]]
    table = wandb.Table(data=data, columns=columns)
    wandb.log({'hyper params table': table})
    train()